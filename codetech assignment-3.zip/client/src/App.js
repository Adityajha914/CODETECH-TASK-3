import React, { useEffect, useRef, useState } from 'react';
import Quill from 'quill';
import 'quill/dist/quill.snow.css';
import { io } from 'socket.io-client';

const TOOLBAR_OPTIONS = [['bold', 'italic', 'underline'], [{ 'list': 'ordered'}, { 'list': 'bullet' }]];

export default function App() {
  const wrapperRef = useRef();
  const [socket, setSocket] = useState();
  const [quill, setQuill] = useState();

  useEffect(() => {
    const s = io('http://localhost:3001');
    setSocket(s);
    return () => s.disconnect();
  }, []);

  useEffect(() => {
    if (socket == null || quill == null) return;

    socket.on('receive-changes', delta => {
      quill.root.innerHTML = delta;
    });

    return () => socket.off('receive-changes');
  }, [socket, quill]);

  useEffect(() => {
    if (socket == null || quill == null) return;

    const handler = () => {
      const data = quill.root.innerHTML;
      socket.emit('send-changes', data);
    };

    quill.on('text-change', handler);
    return () => quill.off('text-change', handler);
  }, [socket, quill]);

  useEffect(() => {
    if (quill == null || socket == null) return;

    socket.once('load-document', content => {
      quill.root.innerHTML = content;
    });
  }, [socket, quill]);

  useEffect(() => {
    const editor = document.createElement('div');
    wrapperRef.current.append(editor);
    const q = new Quill(editor, {
      theme: 'snow',
      modules: {
        toolbar: TOOLBAR_OPTIONS,
      }
    });
    setQuill(q);
  }, []);

  return <div className="container" ref={wrapperRef}></div>;
}
